from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

app = FastAPI(
    title="AI WinterWise API",
    description="A simple AI-assisted winter weather advisory API.",
    version="1.0.0"
)

class WinterRequest(BaseModel):
    city: str
    temperature: float
    humidity: Optional[float] = None
    wind_speed: Optional[float] = None

class WinterResponse(BaseModel):
    city: str
    temperature: float
    risk_level: str
    advice: list[str]

def generate_advice(data: WinterRequest):
    advice = []

    if data.temperature <= 0:
        risk = "High"
        advice.append("Very cold conditions. Wear multiple warm layers.")
        advice.append("Avoid prolonged outdoor exposure.")
    elif data.temperature <= 10:
        risk = "Moderate"
        advice.append("Wear a warm jacket and suitable winter clothing.")
    else:
        risk = "Low"
        advice.append("Normal winter precautions are sufficient.")

    if data.humidity is not None and data.humidity >= 80:
        advice.append("High humidity may make the cold feel stronger.")

    if data.wind_speed is not None and data.wind_speed >= 20:
        advice.append("Strong winds are present. Use wind-protective clothing.")

    advice.append("Stay hydrated and monitor local weather updates.")
    return risk, advice

@app.get("/")
def root():
    return {
        "message": "Welcome to AI WinterWise API",
        "docs": "/docs"
    }

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/winter-advice", response_model=WinterResponse)
def winter_advice(data: WinterRequest):
    if not data.city.strip():
        raise HTTPException(status_code=400, detail="City is required")

    risk, advice = generate_advice(data)

    return WinterResponse(
        city=data.city,
        temperature=data.temperature,
        risk_level=risk,
        advice=advice
    )
