# AI WinterWise API

AI WinterWise API is a beginner-friendly FastAPI project that provides winter weather advice based on temperature, humidity and wind speed.

## Features

- FastAPI REST API
- Automatic winter risk classification
- Weather-based safety advice
- Interactive Swagger API documentation
- Health-check endpoint
- Easy GitHub deployment

## Project Structure

```text
AI_WinterWise_API/
│
├── app/
│   └── main.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Installation

### 1. Create a virtual environment

```bash
python -m venv venv
```

### 2. Activate it

Windows:

```bash
venv\Scripts\activate
```

Linux/macOS:

```bash
source venv/bin/activate
```

### 3. Install packages

```bash
pip install -r requirements.txt
```

### 4. Run the API

```bash
uvicorn app.main:app --reload
```

### 5. Open API documentation

Go to:

```text
http://127.0.0.1:8000/docs
```

## Example Request

POST `/winter-advice`

```json
{
  "city": "Chennai",
  "temperature": 8,
  "humidity": 85,
  "wind_speed": 22
}
```

## Example Response

```json
{
  "city": "Chennai",
  "temperature": 8,
  "risk_level": "Moderate",
  "advice": [
    "Wear a warm jacket and suitable winter clothing.",
    "High humidity may make the cold feel stronger.",
    "Strong winds are present. Use wind-protective clothing.",
    "Stay hydrated and monitor local weather updates."
  ]
}
```

## GitHub Upload

Upload the complete project folder to a GitHub repository named:

`AI-WinterWise-API`

Do not upload `.env` files containing real API keys.
